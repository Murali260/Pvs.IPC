﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Pvs.IPC.Presentation.Startup))]
namespace Pvs.IPC.Presentation
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
